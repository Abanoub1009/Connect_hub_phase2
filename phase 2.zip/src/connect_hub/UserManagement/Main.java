//package connect_hub;
//import org.json.JSONObject;
//import java.io.FileWriter;
//import java.io.IOException;
//import java.util.Scanner;
//import javax.swing.SwingUtilities;
//
//public class Main {
//    public static void main(String[] args) throws IOException {
//        // Command-line input for SignUp (commented out for now)
////         Scanner scan = new Scanner(System.in);
////         System.out.print("Email: ");
////         String email = scan.nextLine();
////         System.out.print("User Name: ");
////         String userName = scan.nextLine();
////         System.out.print("Password: ");
////         String pass = scan.nextLine();
////         System.out.print("Date of Birth: ");
////         String date = scan.nextLine();
////         SignUp sign = new SignUp(null, email, userName, pass, date, "Offline");
//
//        // Command-line input for LogIn (commented out for now)
//        // System.out.print("Email: ");
//        // String emailLog = scan.nextLine();
//        // System.out.print("Password: ");
//        // String passLog = scan.nextLine();
//        // LogIn login = new LogIn(emailLog, passLog);
//
//        // Launching the GUI
//          java.awt.EventQueue.invokeLater(new Runnable() {
//            public void run() {
//                new JFrame1().setVisible(true);
//            }
//        });
//    }
// } 
//
