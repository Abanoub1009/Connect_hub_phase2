The goal of this project is to develop Connect Hub, a foundational social 
networking platform entirely in Java, using Swing for the frontend and core Java 
for the backend. The platform will enable users to manage accounts, create 
posts and stories, manage friendships, and update profiles. A file-based 
database will be used for simplicity, with emphasis on security, usability, and 
collaborative development. 
